import React from 'react';
import { render, screen, within } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { TransactionHistoryWithBlocks } from './TransactionHistoryWithBlocks';
import type { Transaction } from '../types/transaction-types';

// Mock the hook
const mockUseTransactionDataWithBlocks = vi.fn();

vi.mock('../hooks/use-transaction-data-with-blocks', () => ({
  useTransactionDataWithBlocks: () => mockUseTransactionDataWithBlocks(),
}));

// Mock framer-motion to avoid errors in test environment if not testing animations
vi.mock('framer-motion', async () => {
  const actual = await vi.importActual('framer-motion');
  return {
    ...actual,
    AnimatePresence: ({ children }: { children: React.ReactNode }) => <>{children}</>,
    motion: {
      div: ({ children, ...props }: { children: React.ReactNode; [key: string]: any }) => <div {...props}>{children}</div>,
      tr: ({ children, layout, ...props }: { children: React.ReactNode; layout?: any; [key: string]: any }) => <tr {...props}>{children}</tr>,
      td: ({ children, ...props }: { children: React.ReactNode; [key: string]: any }) => <td {...props}>{children}</td>,
    },
  };
});

// Define a base mock transaction object
const mockTransactionBase: Omit<Transaction, 'id' | 'timestamp' | 'type' | 'from' | 'to' | 'amount' | 'tokenSymbol' | 'feeAmount'> = {
  hash: '0x' + Math.random().toString(16).slice(2, 12),
  success: true,
  status: 'Success',
  extrinsicHash: '0x' + Math.random().toString(16).slice(2, 12),
  extrinsicId: Math.random().toString(),
  tokenDecimals: 18, // Default to 18 for REEF
  feeTokenSymbol: 'REEF',
};

describe('TransactionHistoryWithBlocks', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    // Default mock return value for the hook
    mockUseTransactionDataWithBlocks.mockReturnValue({
      transactions: [],
      currentPage: 1,
      hasNextPage: false,
      totalTransactions: 0,
      error: null,
      isFetchingTransactions: false,
      isNavigatingToLastPage: false,
      userInputAddress: 'test-address',
      nativeAddressForCurrentSearch: 'test-address-native',
      handleFirstPage: vi.fn(),
      handlePreviousPage: vi.fn(),
      handleNextPage: vi.fn(),
      handleLastPage: vi.fn(),
      handleAddressSubmit: vi.fn(),
      setUserInputAddress: vi.fn(),
      cacheStats: { size: 0, maxSize: 50, accessOrderLength: 0 },
      blockStats: { hasCurrentBlock: false, currentBlockStartPage: 1, transactionsInBlock: 0, pagesInBlock: 0 },
      // Add any other properties returned by the hook that the component might use
      pageInfoForCurrentPage: null, 
      sortConfig: { key: null, direction: 'desc' },
      handleSort: vi.fn(),
    });
  });

  it('should render correctly with no transactions', () => {
    mockUseTransactionDataWithBlocks.mockReturnValue({
      transactions: [],
      currentPage: 1,
      hasNextPage: false,
      totalTransactions: 0,
      error: null,
      isFetchingTransactions: false,
      isNavigatingToLastPage: false,
      userInputAddress: 'test-address',
      nativeAddressForCurrentSearch: 'test-address-native', // Ensure this is set to trigger the relevant UI path
      handleFirstPage: vi.fn(),
      handlePreviousPage: vi.fn(),
      handleNextPage: vi.fn(),
      handleLastPage: vi.fn(),
      handleAddressSubmit: vi.fn(),
      setUserInputAddress: vi.fn(),
      cacheStats: { size: 0, maxSize: 50, accessOrderLength: 0 },
      blockStats: { hasCurrentBlock: false, currentBlockStartPage: 0, transactionsInBlock: 0, pagesInBlock: 0 },
    });

    render(<TransactionHistoryWithBlocks initialAddress="test-address" />); 

    expect(screen.getByRole('heading', { name: /Transaction History/i })).toBeInTheDocument();
    expect(screen.getByPlaceholderText(/Enter Reef address/i)).toBeInTheDocument();
    // The "Showing transactions for" text was removed from the UI.
    // We now just check for the "no transactions" message.
    expect(screen.getByText(/No transactions found for this address./i)).toBeInTheDocument();

    // Table headers should be present even when there are no transactions.
    expect(screen.getByRole('columnheader', { name: /Date/i })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: /Type/i })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: /Hash/i })).toBeInTheDocument(); 
  });

  // Test Case 1: Incoming REEF Transaction
  it('displays incoming REEF transaction correctly with type, amount, and fee', () => {
    const mockTransactions: Transaction[] = [
      {
        ...mockTransactionBase,
        id: 'tx1',
        timestamp: new Date().toISOString(),
        type: 'INCOMING',
        from: 'senderAddress1',
        to: 'test-address-native',
        amount: '1234560000000000000000', // 1,234.56 REEF
        tokenSymbol: 'REEF',
        tokenDecimals: 18,
        feeAmount: '12340000000000000', // 0.01234 REEF
      },
    ];

    mockUseTransactionDataWithBlocks.mockReturnValueOnce({
      ...mockUseTransactionDataWithBlocks(), // Get defaults
      transactions: mockTransactions,
      totalTransactions: 1,
    });

    render(<TransactionHistoryWithBlocks initialAddress="test-address" />); 

    const table = screen.getByRole('table');
    const rows = within(table).getAllByRole('row');
    // Rows[0] is the header row, rows[1] is the first data row
    expect(rows).toHaveLength(2); // Header + 1 data row

    const firstDataRow = rows[1];
    const cells = within(firstDataRow).getAllByRole('cell');

    // New column order: Date (0), Type (1), Hash (2), From (3), To (4), Amount (5), Fee (6), Status (7)
    expect(within(cells[1]).getByText(/INCOMING/i)).toBeInTheDocument(); // Type
    expect(within(cells[5]).getByText(/1.23K REEF/i)).toBeInTheDocument(); // Amount
    expect(within(cells[6]).getByText(/0.01234 REEF/i)).toBeInTheDocument(); // Fee
    expect(within(cells[7]).getByText(/Success/i)).toBeInTheDocument(); // Status
  });

  // Test Case 2: Outgoing MRD Transaction
  it('displays outgoing MRD transaction correctly with type, amount, and fee', () => {
    const mockTransactions: Transaction[] = [
      {
        ...mockTransactionBase,
        id: 'tx2',
        timestamp: new Date().toISOString(),
        type: 'OUTGOING',
        from: 'test-address-native', // The current address
        to: 'recipientAddress2',
        amount: '50500000000000000000000', // 50.5K MRD
        tokenSymbol: 'MRD',
        tokenDecimals: 18, // Assuming MRD also has 18 decimals for this test
        feeAmount: '5670000000000000', // 0.00567 REEF
      },
    ];

    mockUseTransactionDataWithBlocks.mockReturnValueOnce({
      ...mockUseTransactionDataWithBlocks(), // Get defaults
      transactions: mockTransactions,
      totalTransactions: 1,
    });

    render(<TransactionHistoryWithBlocks initialAddress="test-address" />); 

    const table = screen.getByRole('table');
    const rows = within(table).getAllByRole('row');
    expect(rows).toHaveLength(2); // Header + 1 data row

    const firstDataRow = rows[1];
    const cells = within(firstDataRow).getAllByRole('cell');

    // New column order: Date (0), Type (1), Hash (2), From (3), To (4), Amount (5), Fee (6), Status (7)
    expect(within(cells[1]).getByText(/OUTGOING/i)).toBeInTheDocument(); // Type
    expect(within(cells[5]).getByText(/50.5K MRD/i)).toBeInTheDocument(); // Amount
    expect(within(cells[6]).getByText(/0.00567 REEF/i)).toBeInTheDocument(); // Fee (rounded)
    expect(within(cells[7]).getByText(/Success/i)).toBeInTheDocument(); // Status
  });

  // Test Case 3: Transaction with missing token symbol (defaults to REEF)
  it('displays transaction with missing token symbol correctly (defaults to REEF)', () => {
    const mockTransactions: Transaction[] = [
      {
        ...mockTransactionBase,
        id: 'tx3',
        timestamp: new Date().toISOString(),
        type: 'INCOMING',
        from: 'senderAddress3',
        to: 'test-address-native',
        amount: '1500000000000000000000', // 1.5K REEF
        tokenSymbol: '', // Missing symbol
        tokenDecimals: 18,
        feeAmount: '1000000000000000', // 0.001 REEF
      },
    ];

    mockUseTransactionDataWithBlocks.mockReturnValueOnce({
      ...mockUseTransactionDataWithBlocks(),
      transactions: mockTransactions,
      totalTransactions: 1,
      nativeAddressForCurrentSearch: 'test-address-native',
    });

    render(<TransactionHistoryWithBlocks initialAddress="test-address" />);
    const table = screen.getByRole('table');
    const rows = within(table).getAllByRole('row');
    const firstDataRow = rows[1];
    const cells = within(firstDataRow).getAllByRole('cell');

    // Check amount and fee (indices 5 and 6)
    expect(within(cells[5]).getByText(/1.5K REEF/i)).toBeInTheDocument();
    expect(within(cells[6]).getByText(/0.001 REEF/i)).toBeInTheDocument();
    // Check type column (index 1)
    expect(within(cells[1]).getByText(/INCOMING/i)).toBeInTheDocument();
  });

  // Test Case 4: Transaction with zero amount
  it('displays transaction with zero amount correctly', () => {
    const mockTransactions: Transaction[] = [
      {
        ...mockTransactionBase,
        id: 'tx4',
        timestamp: new Date().toISOString(),
        type: 'INCOMING', // Type doesn't matter as much as amount formatting here
        from: 'senderAddress4',
        to: 'test-address-native',
        amount: '0',
        tokenSymbol: 'XYZ',
        tokenDecimals: 0,
        feeAmount: '1000000000000000', // 0.001 REEF
      },
    ];

    mockUseTransactionDataWithBlocks.mockReturnValueOnce({
      ...mockUseTransactionDataWithBlocks(),
      transactions: mockTransactions,
      totalTransactions: 1,
      nativeAddressForCurrentSearch: 'test-address-native',
    });

    render(<TransactionHistoryWithBlocks initialAddress="test-address" />);
    const table = screen.getByRole('table');
    const rows = within(table).getAllByRole('row');
    const firstDataRow = rows[1];
    const cells = within(firstDataRow).getAllByRole('cell');

    // New column order: Date (0), Type (1), Hash (2), From (3), To (4), Amount (5), Fee (6), Status (7)
    expect(within(cells[5]).getByText(/0 XYZ/i)).toBeInTheDocument(); // Amount should be '0 XYZ'
  });

  // Test Case 5: Self-transaction
  it('displays self-transaction correctly', () => {
    const mockTransactions: Transaction[] = [
      {
        ...mockTransactionBase,
        id: 'tx4',
        timestamp: new Date().toISOString(),
        type: 'SELF',
        from: 'test-address-native',
        to: 'test-address-native',
        amount: '2500000000000000000000', // 2,500 REEF
        tokenSymbol: 'REEF',
        tokenDecimals: 18,
        feeAmount: '2000000000000000', // 0.002 REEF
      },
    ];

    mockUseTransactionDataWithBlocks.mockReturnValueOnce({
      ...mockUseTransactionDataWithBlocks(),
      transactions: mockTransactions,
      totalTransactions: 1,
      nativeAddressForCurrentSearch: 'test-address-native',
    });

    render(<TransactionHistoryWithBlocks initialAddress="test-address" />);
    const table = screen.getByRole('table');
    const rows = within(table).getAllByRole('row');
    const firstDataRow = rows[1];
    const cells = within(firstDataRow).getAllByRole('cell');

    // New column order: Date (0), Type (1), Hash (2), From (3), To (4), Amount (5), Fee (6), Status (7)
    expect(within(cells[5]).getByText(/2.5K REEF/i)).toBeInTheDocument();
    expect(within(cells[1]).getByText(/SELF/i)).toBeInTheDocument(); // Type should be SELF for self-transfer
  });

  // Test Case 6: MRD Transaction Amount Rendering (0 decimals from map/default)
  it('displays MRD transaction amount correctly using 0 decimals', async () => {
    const mrdTx = {
      ...mockTransactionBase,
      id: 'tx_mrd_01',
      timestamp: new Date(Date.now() + 500).toISOString(),
      type: 'OUTGOING',
      from: 'test-address-native',
      to: 'recipientAddress_mrd',
      amount: '50',
      tokenSymbol: 'MRD',
      tokenDecimals: 0,
      feeAmount: '5000000000000000', // 0.005 REEF
    };
    mockUseTransactionDataWithBlocks.mockReturnValue({
      transactions: [mrdTx],
      currentPage: 1,
      hasNextPage: false,
      totalTransactions: 1,
      error: null,
      isFetchingTransactions: false,
      isNavigatingToLastPage: false,
      userInputAddress: 'test-address',
      nativeAddressForCurrentSearch: 'test-address-native',
      handleFirstPage: vi.fn(),
      handlePreviousPage: vi.fn(),
      handleNextPage: vi.fn(),
      handleLastPage: vi.fn(),
      handleAddressSubmit: vi.fn(),
      setUserInputAddress: vi.fn(),
      cacheStats: { size: 0, maxSize: 50, accessOrderLength: 0 },
      blockStats: { hasCurrentBlock: false, currentBlockStartPage: 0, transactionsInBlock: 0, pagesInBlock: 0 },
      pageInfoForCurrentPage: null, 
      sortConfig: { key: null, direction: 'desc' },
      handleSort: vi.fn(),
    });

    render(<TransactionHistoryWithBlocks initialAddress="test-address" />);
    const rows = await screen.findAllByRole('row');
    const cells = within(rows[1]).getAllByRole('cell');

    // New column order: Date (0), Type (1), Hash (2), From (3), To (4), Amount (5), Fee (6), Status (7)
    expect(within(cells[1]).getByText(/OUTGOING/i)).toBeInTheDocument(); // Type
    expect(within(cells[5]).getByText(/50 MRD/i)).toBeInTheDocument(); // Amount
    expect(within(cells[6]).getByText(/0.005 REEF/i)).toBeInTheDocument(); // Fee
  });

  // Test Case 7: NFT Transaction (zero amount)
  it('should display "NFT" for zero-amount NFT transfers', async () => {
    const nftTx: Transaction = {
      ...mockTransactionBase,
      id: 'tx_nft_01',
      timestamp: new Date().toISOString(),
      type: 'INCOMING',
      from: 'nftSenderAddress',
      to: 'test-address-native',
      amount: '0',
      tokenSymbol: 'SqwidERC1155',
      tokenDecimals: 0,
      feeAmount: '12000000000000000', // 0.012 REEF
    };

    mockUseTransactionDataWithBlocks.mockReturnValue({
      ...mockUseTransactionDataWithBlocks(),
      transactions: [nftTx],
      totalTransactions: 1,
      nativeAddressForCurrentSearch: 'test-address-native',
    });

    render(<TransactionHistoryWithBlocks initialAddress="test-address" />);
    const rows = await screen.findAllByRole('row');
    const cells = within(rows[1]).getAllByRole('cell');

    // New column order: Date (0), Type (1), Hash (2), From (3), To (4), Amount (5), Fee (6), Status (7)
    expect(within(cells[5]).getByText(/^NFT$/i)).toBeInTheDocument(); // Amount should be exactly 'NFT'
  });

  it('renders table headers correctly when transactions are present', () => {
    const mockTransactions: Transaction[] = [
      {
        ...mockTransactionBase,
        id: 'txTableHeaderTest',
        timestamp: new Date().toISOString(),
        type: 'INCOMING',
        from: 'senderAddressHeader',
        to: 'test-address-native',
        amount: '100000000000000000000', // 100 REEF
        tokenSymbol: 'REEF',
        tokenDecimals: 18,
        feeAmount: '1000000000000000', // 0.001 REEF
      },
    ];

    mockUseTransactionDataWithBlocks.mockReturnValueOnce({
      ...mockUseTransactionDataWithBlocks(),
      transactions: mockTransactions,
      totalTransactions: 1,
      nativeAddressForCurrentSearch: 'test-address-native',
    });

    render(<TransactionHistoryWithBlocks initialAddress="test-address" />);
    expect(screen.getByRole('columnheader', { name: /Date/i })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: /Type/i })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: /Hash/i })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: /From/i })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: /To/i })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: /Amount/i })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: /Fee/i })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: /Status/i })).toBeInTheDocument();
  });


});
