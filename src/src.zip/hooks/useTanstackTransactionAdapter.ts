import { useEffect, useMemo } from 'react';
import { useTransactionDataWithBlocks } from './use-transaction-data-with-blocks';
import { usePaginationAndSorting } from './usePaginationAndSorting';


export function useTanstackTransactionAdapter(address: string) {
  const { pagination, setPagination, sorting, setSorting } = usePaginationAndSorting();

  const {
    transactions,
    currentPage,
    totalTransactions,
    isFetchingTransactions,
    handleNextPage,
    handlePreviousPage,
    handleAddressSubmit,
  } = useTransactionDataWithBlocks(address, sorting);

  useEffect(() => {
    handleAddressSubmit(address);
  }, [address, handleAddressSubmit]);

  const pageCount = useMemo(() => {
    return totalTransactions > 0
      ? Math.ceil(totalTransactions / pagination.pageSize)
      : -1; // -1 indicates unknown page count for TanStack Table
  }, [totalTransactions, pagination.pageSize]);

  // This effect synchronizes TanStack's state with our fetching logic
  useEffect(() => {
    const targetPage = pagination.pageIndex + 1;
    if (targetPage > currentPage) {
      handleNextPage();
    } else if (targetPage < currentPage) {
      handlePreviousPage();
    }
  }, [pagination.pageIndex, currentPage, handleNextPage, handlePreviousPage]);

  return {
    transactions,
    isLoading: isFetchingTransactions,
    pageCount,
    pagination,
    setPagination,
    sorting,
    setSorting,
  };
}
