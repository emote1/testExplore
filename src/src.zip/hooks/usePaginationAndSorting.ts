import { useState } from 'react';
import { PaginationState, SortingState } from '@tanstack/react-table';
import { PAGINATION_CONFIG } from '../constants/pagination';

/**
 * A custom hook to manage the state for pagination and sorting,
 * primarily for use with TanStack Table and our data fetching hooks.
 */
export function usePaginationAndSorting() {
  // State for TanStack Table's pagination
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0, // Start at the first page
    pageSize: PAGINATION_CONFIG.UI_TRANSACTIONS_PER_PAGE,
  });

  // State for TanStack Table's sorting
  const [sorting, setSorting] = useState<SortingState>([]);

  return {
    pagination,
    setPagination,
    sorting,
    setSorting,
  };
}
