import { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import axios from 'axios';
import { SortingState } from '@tanstack/react-table';
import type { Transaction, SortConfig, SignedData, TransactionBlock, BlockPaginationState } from '../types/transaction-types';
import type { ApiPageInfo, ApiTransfersConnection, ApiTransactionEdge } from '../types/reefscan-api';
import { PaginationCacheManager } from '../data/cache-manager';
import { PAGINATION_CONFIG } from '../constants/pagination';
import { determineDisplayType } from '../utils/reefscan-helpers';
import {
  createTransactionBlock,
  extractPageFromBlock,
  canServePageFromBlock,
  getPagesInBlock
} from '../utils/block-pagination';
import { useTransferSubscription } from './useTransferSubscription';

// Define a helper interface for parsed contract_data
interface ParsedContractData {
  name?: string;
  symbol?: string;
  decimals?: number;
}

// Error interfaces
interface AppError {
  userMessage: string;
  originalError?: unknown;
}

interface GraphQLError {
  message: string;
}

const API_URL = 'https://squid.subsquid.io/reef-explorer/graphql';

// Hook return interface
export interface UseTransactionDataReturn {
  transactions: Transaction[];
  currentPage: number;
  hasNextPage: boolean;
  totalTransactions: number;
  error: string | null;
  isFetchingTransactions: boolean;
  isNavigatingToLastPage: boolean;
  isLastPageNavigable: boolean;
  userInputAddress: string;
  currentSearchAddress: string;
  nativeAddressForCurrentSearch: string | null;
  pageInfoForCurrentPage: ApiPageInfo | null;
  sortConfig: SortConfig;
  handleFirstPage: () => void;
  handlePreviousPage: () => void;
  handleNextPage: () => void;
  handleLastPage: () => void;
  handleAddressSubmit: (address: string) => void;
  setUserInputAddress: React.Dispatch<React.SetStateAction<string>>;
  handleSort: (key: keyof Transaction | null) => void;
  cacheStats: { size: number; maxSize: number; accessOrderLength: number; };
  // New block-related stats for debugging
  blockStats: {
    hasCurrentBlock: boolean;
    currentBlockStartPage: number;
    transactionsInBlock: number;
    pagesInBlock: number;
  };
  prependNewTransaction: (transaction: Transaction) => void;
}

// Helper to parse signedData from the API
const parseSignedData = (data: any): SignedData | undefined => {
  if (!data) {
    return undefined;
  }
  try {
    const rawSignedData = typeof data === 'string' ? JSON.parse(data) : data;

    if (rawSignedData && rawSignedData.fee && typeof rawSignedData.fee.partialFee === 'string') {
      return { 
        fee: { 
          partialFee: rawSignedData.fee.partialFee 
        } 
      };
    }
    if (rawSignedData && typeof rawSignedData.partialFee === 'string') {
      return { fee: { partialFee: rawSignedData.partialFee } };
    }
    return undefined;
  } catch (e) {
    // Silently ignore parsing errors, as this data is not critical
    return undefined;
  }
};

// Main hook implementation with block optimization
export function useTransactionDataWithBlocks(
  initialAddress: string = '',
  sorting: SortingState
): UseTransactionDataReturn {
  // Cache manager instance (kept for fallback scenarios)
  const cacheManager = useRef(new PaginationCacheManager());
  
  // Traditional state management
  const [pageInfoForCurrentPage, setPageInfoForCurrentPage] = useState<ApiPageInfo | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [userInputAddress, setUserInputAddress] = useState<string>(initialAddress);
  const [currentSearchAddress, setCurrentSearchAddress] = useState<string>('');
  const [nativeAddressForCurrentSearch, setNativeAddressForCurrentSearch] = useState<string | null>('');
  const nativeAddressRef = useRef(nativeAddressForCurrentSearch);
  useEffect(() => {
    nativeAddressRef.current = nativeAddressForCurrentSearch;
  }, [nativeAddressForCurrentSearch]);
  const [totalTransactions, setTotalTransactions] = useState(0);
  const [hasNextPage, setHasNextPage] = useState(false);
  const [isLastPageNavigable, setIsLastPageNavigable] = useState(true);
  const [error, setError] = useState<AppError | null>(null);
  const [isFetchingTransactions, setIsFetchingTransactions] = useState(false);
  const [isNavigatingToLastPage, setIsNavigatingToLastPage] = useState(false);
  const [isInitialDataSet, setIsInitialDataSet] = useState(false);

  // New block-based state
  const [blockCache, setBlockCache] = useState<Map<number, TransactionBlock>>(new Map());
  const [blockState, setBlockState] = useState<BlockPaginationState>({
    currentBlock: null,
    currentBlockStartPage: 1,
    remainingTransactions: []
  });

  // API function to fetch paginated transfers with configurable page size
  const fetchPaginatedTransfers = useCallback(async (
    nativeAddress: string,
    pageSize: number,
    cursor?: string | null
  ): Promise<ApiTransfersConnection> => {
    let paginationArgs = `first: ${pageSize}`;
    if (cursor) {
      paginationArgs += `, after: "${cursor}"`;
    }

    const query = `
      query GetTransfers($nativeAddressVariable: String!) {
        transfersConnection(
          orderBy: timestamp_DESC,
          where: {
            AND: [
              { success_eq: true },
              { OR: [
                  { from: { id_eq: $nativeAddressVariable } },
                  { to: { id_eq: $nativeAddressVariable } }
                ]
              }
            ]
          },
          ${paginationArgs}
        ) {
          edges {
            node {
              id
              timestamp
              denom
              amount
              success
              extrinsicHash
              extrinsicId
              type
              token {
                id
                name
                contractData
              }
              from { id evmAddress }
              to { id evmAddress }
              signedData
            }
          }
          pageInfo {
            hasNextPage
            hasPreviousPage
            startCursor
            endCursor
          }
          totalCount
        }
      }
    `;

    const variables = {
      nativeAddressVariable: nativeAddress
    };

    const response = await axios.post(API_URL, { query, variables });
    
    if (response.data?.errors) {
      throw new Error(response.data.errors.map((e: GraphQLError) => e.message).join(', '));
    }

    if (response.data?.data?.transfersConnection) {
      return response.data.data.transfersConnection;
    } else {
      throw new Error('Invalid data structure or transfersConnection is null.');
    }
  }, []);

  // Process transaction edges into clean Transaction objects
  const processTransactionEdges = useCallback((edges: ApiTransactionEdge[]): Transaction[] => {
    // nativeAddressRef.current holds the stable, current address for the search.
    // This check prevents processing if the address isn't set, avoiding errors.
    if (!nativeAddressRef.current) return [];

    const processedTransactions: Transaction[] = edges.map((edge) => {
      const tx = edge.node; // The raw transaction data from the API edge.

      // Parse auxiliary data safely.
      const signedData = parseSignedData(tx.signedData);
      
      let parsedContractData: ParsedContractData | undefined;
      try {
        if (tx.token?.contractData) {
          // contractData can be a stringified JSON or an object.
          parsedContractData = typeof tx.token.contractData === 'string'
            ? JSON.parse(tx.token.contractData)
            : tx.token.contractData;
        }
      } catch (e) {
        // Silently ignore parsing errors for non-critical data.
        parsedContractData = undefined;
      }

      // Determine the transaction display type ('SEND', 'RECEIVE', etc.).
      // This now uses the correct signature with 4 arguments.
      const displayType = determineDisplayType(tx.type, tx.from.id, tx.to?.id || '', nativeAddressRef.current!);

      // Construct the final, clean Transaction object.
      // This object structure matches the `Transaction` type definition.
      return {
        id: tx.id,
        hash: tx.extrinsicHash || '', // Ensure hash is never null.
        timestamp: tx.timestamp,
        from: tx.from.id,
        to: tx.to?.id || 'N/A', // Handle cases where 'to' might be null.
        fromEvm: tx.from.evmAddress,
        toEvm: tx.to?.evmAddress,
        amount: tx.amount,
        success: tx.success,
        status: tx.success ? 'Success' : 'Fail', // Simplified status based on success flag.
        extrinsicHash: tx.extrinsicHash,
        extrinsicId: tx.extrinsicId,
        type: displayType, // Use the determined display type directly.
        feeAmount: signedData?.fee?.partialFee || '0', // Safely access fee.
        feeTokenSymbol: 'REEF', // Assume REEF for fees.
        tokenSymbol: parsedContractData?.symbol || tx.token.name || 'Unknown', // Fallback for token symbol.
        tokenDecimals: parsedContractData?.decimals ?? 18, // Default to 18 decimals.
        signedData,
        raw: tx, // Keep the original transaction data for debugging or other purposes.
      };
    });

    return processedTransactions;
  }, []); // The dependency array is empty because we use a ref for the native address,
          // breaking the cycle and ensuring the function reference is stable.

  // Fetch a new block of transactions
  const fetchNewBlock = useCallback(async (
    nativeAddress: string,
    cursor?: string | null
  ): Promise<TransactionBlock> => {
    const fetchSize = PAGINATION_CONFIG.ENABLE_BLOCK_OPTIMIZATION 
      ? PAGINATION_CONFIG.BLOCK_FETCH_SIZE 
      : PAGINATION_CONFIG.UI_TRANSACTIONS_PER_PAGE;

    const apiData = await fetchPaginatedTransfers(nativeAddress, fetchSize, cursor);
    const processedTransactions = processTransactionEdges(apiData.edges);
    
    return createTransactionBlock(
      processedTransactions,
      apiData.pageInfo,
      apiData.totalCount,
      nativeAddress
    );
  }, [fetchPaginatedTransfers, processTransactionEdges]);

  // Load page data using block optimization
  const loadPageData = useCallback(async (
    pageNumber: number,
    nativeAddress: string,
    cursor?: string | null
  ) => {
    if (!nativeAddress) return;

    setIsFetchingTransactions(true);
    setError(null);

    try {
      // 1. Check if we can serve this page from the current block
      if (PAGINATION_CONFIG.ENABLE_BLOCK_OPTIMIZATION && 
          canServePageFromBlock(blockState.currentBlock, pageNumber, blockState.currentBlockStartPage)) {
        
        const result = extractPageFromBlock(blockState.currentBlock!, pageNumber, blockState.currentBlockStartPage);
        
        setTransactions(result.transactions);
        setCurrentPage(pageNumber);
        setHasNextPage(result.hasMore);
        setTotalTransactions(blockState.currentBlock!.totalCount);
        
        setPageInfoForCurrentPage({
          hasNextPage: result.hasMore,
          hasPreviousPage: pageNumber > 1,
          startCursor: blockState.currentBlock!.pageInfo.startCursor,
          endCursor: blockState.currentBlock!.pageInfo.endCursor
        });
        return; // Served from current block
      }

      // 2. Check if we can serve from a cached block
      for (const [startPage, cachedBlock] of blockCache.entries()) {
        if (canServePageFromBlock(cachedBlock, pageNumber, startPage)) {
          // Found a block in the cache! Use it.
          const result = extractPageFromBlock(cachedBlock, pageNumber, startPage);

          setBlockState({ currentBlock: cachedBlock, currentBlockStartPage: startPage, remainingTransactions: [] });
          setTransactions(result.transactions);
          setCurrentPage(pageNumber);
          setHasNextPage(result.hasMore);
          setTotalTransactions(cachedBlock.totalCount);
          setPageInfoForCurrentPage({
            hasNextPage: result.hasMore,
            hasPreviousPage: pageNumber > 1,
            startCursor: cachedBlock.pageInfo.startCursor,
            endCursor: cachedBlock.pageInfo.endCursor
          });
          return; // Served from cache
        }
      }

      // 3. Need to fetch a new block
      const newBlock = await fetchNewBlock(nativeAddress, cursor);
      
      // Add new block to cache
      setBlockCache(prevCache => new Map(prevCache).set(pageNumber, newBlock));
      
      // Update block state with the new block
      setBlockState({
        currentBlock: newBlock,
        currentBlockStartPage: pageNumber,
        remainingTransactions: []
      });

      // Extract first page from the new block
      const result = extractPageFromBlock(newBlock, pageNumber, pageNumber);
      
      setTransactions(result.transactions);
      setCurrentPage(pageNumber);
      setHasNextPage(result.hasMore);
      setTotalTransactions(newBlock.totalCount);
      
      setPageInfoForCurrentPage({
        hasNextPage: result.hasMore,
        hasPreviousPage: pageNumber > 1,
        startCursor: newBlock.pageInfo.startCursor,
        endCursor: newBlock.pageInfo.endCursor
      });

      const totalPages = Math.ceil(newBlock.totalCount / PAGINATION_CONFIG.UI_TRANSACTIONS_PER_PAGE);
      const pagesToJump = totalPages - pageNumber;
      setIsLastPageNavigable(pagesToJump <= PAGINATION_CONFIG.MAX_SEQUENTIAL_FETCH_PAGES);

    } catch (err) {
      // Only log errors in non-test environments to avoid stderr pollution during tests
      if (process.env.NODE_ENV !== 'test') {
        console.error('Error loading page data:', err);
      }
      setError({
        userMessage: 'Ошибка загрузки данных. Попробуйте обновить страницу.',
        originalError: err
      });
    } finally {
      setIsFetchingTransactions(false);
    }
  }, [blockState, fetchNewBlock, blockCache]);

  // Ref to hold the latest loadPageData function to break dependency cycles
  const loadPageDataRef = useRef(loadPageData);
  useEffect(() => {
    loadPageDataRef.current = loadPageData;
  }, [loadPageData]);

  // Navigation handlers
  const handleNextPage = useCallback(async () => {
    if (!nativeAddressForCurrentSearch || isFetchingTransactions || !hasNextPage) return;
    const nextPage = currentPage + 1;
    await loadPageData(nextPage, nativeAddressForCurrentSearch, blockState.currentBlock?.pageInfo.endCursor);
  }, [currentPage, nativeAddressForCurrentSearch, isFetchingTransactions, blockState, loadPageData, hasNextPage]);

  const handlePreviousPage = useCallback(async () => {
    if (!nativeAddressForCurrentSearch || isFetchingTransactions || currentPage <= 1) return;
    const prevPage = currentPage - 1;
    await loadPageData(prevPage, nativeAddressForCurrentSearch, null); // Cursor is null for previous, cache will be checked
  }, [currentPage, nativeAddressForCurrentSearch, isFetchingTransactions, loadPageData]);

  const handleFirstPage = useCallback(async () => {
    if (!nativeAddressForCurrentSearch || isFetchingTransactions) return;
    await loadPageData(1, nativeAddressForCurrentSearch);
  }, [nativeAddressForCurrentSearch, isFetchingTransactions, loadPageData]);

  const handleLastPage = useCallback(async () => {
    if (!nativeAddressForCurrentSearch || isFetchingTransactions || !totalTransactions || !isLastPageNavigable) return;

    setIsNavigatingToLastPage(true);
    setError(null);

    try {
      const lastPage = Math.ceil(totalTransactions / PAGINATION_CONFIG.BLOCK_FETCH_SIZE);
      await loadPageData(lastPage, nativeAddressForCurrentSearch);
    } catch (err) {
      console.error('Error navigating to last page:', err);
      setError({
        userMessage: 'Ошибка при переходе на последнюю страницу.',
        originalError: err,
      });
    } finally {
      setIsNavigatingToLastPage(false);
    }
  }, [
    nativeAddressForCurrentSearch,
    isFetchingTransactions,
    totalTransactions,
    isLastPageNavigable,
    loadPageData,
  ]);

  // Address handling
  const handleAddressSubmit = useCallback(async (address: string) => {
    if (!address.trim()) return;

    setCurrentSearchAddress(address);
    setNativeAddressForCurrentSearch(null); // Reset while resolving
    setError(null);
    setTransactions([]);
    setCurrentPage(1);
    setBlockState({ currentBlock: null, currentBlockStartPage: 1, remainingTransactions: [] });
    setBlockCache(new Map());
    setIsInitialDataSet(false);
    setIsLastPageNavigable(true);

    try {
      // Resolve native address
      // For simplicity, we'll assume the input address is the native address
      setNativeAddressForCurrentSearch(address);
      
      // Load first page
      await loadPageDataRef.current(1, address);
    } catch (err) {
      console.error('Error resolving address:', err);
      setError({
        userMessage: 'Failed to resolve address. Please check the address and try again.',
        originalError: err,
      });
    }
  }, [setCurrentSearchAddress, setNativeAddressForCurrentSearch, setError, setTransactions, setCurrentPage, setBlockState, setBlockCache, setIsInitialDataSet]);

  // Sorting handler (simplified)
  const sortConfig: SortConfig = useMemo(() => {
    if (sorting.length > 0) {
      const sort = sorting[0];
      return { key: sort.id as keyof Transaction, direction: sort.desc ? 'desc' : 'asc' };
    }
    return { key: 'timestamp', direction: 'desc' }; // Default sort
  }, [sorting]);

  // Real-time transaction updates
  const prependNewTransaction = useCallback((transaction: Transaction) => {
    setTransactions(prevTransactions => {
      // Check if transaction already exists to avoid duplicates
      const exists = prevTransactions.some(tx => tx.id === transaction.id);
      if (exists) return prevTransactions;
      
      // Add new transaction at the beginning and limit to UI_TRANSACTIONS_PER_PAGE
      return [transaction, ...prevTransactions].slice(0, PAGINATION_CONFIG.UI_TRANSACTIONS_PER_PAGE);
    });
    
    // Increment total count for new transactions
    setTotalTransactions(prevTotal => prevTotal + 1);
  }, []); // No dependencies - uses functional state updates

  // Subscribe to new transactions only on first page
  useTransferSubscription({
    nativeAddress: nativeAddressForCurrentSearch,
    onNewTransaction: prependNewTransaction,
    isEnabled: currentPage === 1 && !!nativeAddressForCurrentSearch
  });

  // Cache stats
  const cacheStats = useMemo(() => {
    const stats = cacheManager.current.getStats();
    return {
      size: stats.size,
      maxSize: stats.maxSize,
      accessOrderLength: stats.accessOrderLength
    };
  }, []);

  // Block stats for debugging
  const blockStats = useMemo(() => ({
    hasCurrentBlock: blockState.currentBlock !== null,
    currentBlockStartPage: blockState.currentBlockStartPage,
    transactionsInBlock: blockState.currentBlock?.transactions.length || 0,
    pagesInBlock: blockState.currentBlock ? getPagesInBlock(blockState.currentBlock) : 0
  }), [blockState]);

  // Initialize with address if provided
  useEffect(() => {
    if (initialAddress && !isInitialDataSet) {
      handleAddressSubmit(initialAddress);
      setIsInitialDataSet(true);
    }
  }, [initialAddress, isInitialDataSet, handleAddressSubmit]);

  return {
    transactions,
    currentPage,
    hasNextPage,
    totalTransactions,
    error: error?.userMessage || null,
    isFetchingTransactions,
    isNavigatingToLastPage,
    isLastPageNavigable,
    userInputAddress,
    currentSearchAddress,
    nativeAddressForCurrentSearch,
    pageInfoForCurrentPage,
    sortConfig,
    handleFirstPage,
    handlePreviousPage,
    handleNextPage,
    handleLastPage,
    handleAddressSubmit,
    setUserInputAddress,
    handleSort: () => {}, // Placeholder, as sorting is now handled by TanStack
    cacheStats,
    blockStats,
    prependNewTransaction
  };
}
