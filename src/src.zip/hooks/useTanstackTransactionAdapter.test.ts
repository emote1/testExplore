import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook } from '@testing-library/react';
import { useTanstackTransactionAdapter } from './useTanstackTransactionAdapter';
import { useTransactionDataWithBlocks } from './use-transaction-data-with-blocks';
import { usePaginationAndSorting } from './usePaginationAndSorting';
import type { UseTransactionDataReturn } from './use-transaction-data-with-blocks';

// Mock the core data hooks to isolate the adapter
vi.mock('./use-transaction-data-with-blocks');
vi.mock('./usePaginationAndSorting');

// Define a complete and typed mock for the return value of the data hook
const mockUseTransactionData: UseTransactionDataReturn = {
  transactions: [],
  totalTransactions: 100,
  currentPage: 1,
  hasNextPage: true,
  isFetchingTransactions: false,
  nativeAddressForCurrentSearch: 'test-address',
  sortConfig: { key: 'timestamp', direction: 'desc' },
  handleNextPage: vi.fn(),
  handlePreviousPage: vi.fn(),
  handleAddressSubmit: vi.fn(),
  handleSort: vi.fn(),
  error: null,
  isLastPageNavigable: true,
  isNavigatingToLastPage: false,
  userInputAddress: 'test-address',
  currentSearchAddress: 'test-address',
  pageInfoForCurrentPage: null,
  handleFirstPage: vi.fn(),
  handleLastPage: vi.fn(),
  setUserInputAddress: vi.fn(),
  cacheStats: { size: 0, maxSize: 0, accessOrderLength: 0 },
  blockStats: { hasCurrentBlock: false, currentBlockStartPage: 0, pagesInBlock: 0, transactionsInBlock: 0 },
  prependNewTransaction: vi.fn(),
};

describe('useTanstackTransactionAdapter', () => {
  const mockSetPagination = vi.fn();
  const mockSetSorting = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
    (useTransactionDataWithBlocks as vi.Mock).mockReturnValue(mockUseTransactionData);
    (usePaginationAndSorting as vi.Mock).mockReturnValue({
      pagination: { pageIndex: 0, pageSize: 20 },
      setPagination: mockSetPagination,
      sorting: [],
      setSorting: mockSetSorting,
    });
  });

  it('should initialize and call handleAddressSubmit on mount', () => {
    renderHook(() => useTanstackTransactionAdapter('test-address'));
    expect(mockUseTransactionData.handleAddressSubmit).toHaveBeenCalledWith('test-address');
  });

  it('should call handleNextPage when pagination pageIndex increases', () => {
    const { rerender } = renderHook(() => useTanstackTransactionAdapter('test-address'));

    // Mock a state update from the pagination hook
    (usePaginationAndSorting as vi.Mock).mockReturnValue({
      pagination: { pageIndex: 1, pageSize: 20 }, // pageIndex increased
      setPagination: mockSetPagination,
      sorting: [],
      setSorting: mockSetSorting,
    });

    rerender();

    expect(mockUseTransactionData.handleNextPage).toHaveBeenCalled();
  });

  it('should call handlePreviousPage when pagination pageIndex decreases', () => {
    // Setup initial state where currentPage is > 1
    (useTransactionDataWithBlocks as vi.Mock).mockReturnValue({
      ...mockUseTransactionData,
      currentPage: 3,
    });

    const { rerender } = renderHook(() => useTanstackTransactionAdapter('test-address'));

    // Mock a state update from the pagination hook
    (usePaginationAndSorting as vi.Mock).mockReturnValue({
      pagination: { pageIndex: 1, pageSize: 20 }, // pageIndex is 1 (page 2), which is less than currentPage 3
      setPagination: mockSetPagination,
      sorting: [],
      setSorting: mockSetSorting,
    });

    rerender();

    expect(mockUseTransactionData.handlePreviousPage).toHaveBeenCalled();
  });
});
