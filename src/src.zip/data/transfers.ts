import { gql } from '@apollo/client';

export const TRANSFER_SUBSCRIPTION = gql`
  subscription TransferSubscription($where: TransferWhereInput) {
    transfers(where: $where, limit: 1, orderBy: timestamp_DESC) {
      id
      amount
      timestamp
      success
      extrinsicHash
      extrinsicId
      from {
        id
        evmAddress
      }
      to {
        id
        evmAddress
      }
      token {
        id
        name
        contractData
      }
      blockHeight
    }
  }
`;

export const PAGINATED_TRANSACTIONS_QUERY = gql`
  query TransfersQuery($first: Int!, $after: String, $where: TransferWhereInput, $orderBy: [TransfersOrderByInput!]!) {
    transfersConnection(orderBy: $orderBy, first: $first, after: $after, where: $where) {
      edges {
        node {
          id
          amount
          timestamp
          success
          extrinsicHash
          extrinsicId
          from {
            id
            evmAddress
          }
          to {
            id
            evmAddress
          }
          token {
            id
            name
            contractData
          }
          blockHeight
        }
      }
      pageInfo {
        hasNextPage
        endCursor
      }
      totalCount
    }
  }
`;
