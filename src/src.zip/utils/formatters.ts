// src/utils/formatters.ts

export function formatTimestamp(timestamp: string, locale = 'en-US'): string {
  const date = new Date(timestamp);
  const options: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  };

  if (isNaN(date.getTime())) {
    // Fallback for numeric string, which might be in milliseconds
    const numericTimestamp = parseInt(timestamp, 10);
    if (!isNaN(numericTimestamp)) {
      const numericDate = new Date(numericTimestamp);
      if (!isNaN(numericDate.getTime())) {
        return numericDate.toLocaleString(locale, options);
      }
    }
    return 'Invalid Date';
  }
  return date.toLocaleString(locale, options);
}

export function shortenHash(hash: string | undefined, startChars = 6, endChars = 4): string {
  if (!hash) return 'N/A';
  if (hash.length <= startChars + endChars + 3) return hash; // +3 for '...'
  return `${hash.substring(0, startChars)}...${hash.substring(hash.length - endChars)}`;
}

/**
 * Formats a token amount from its smallest unit (e.g., wei) to a readable string.
 * @param amountStr The amount as a string.
 * @param decimals The number of decimals the token uses.
 * @param symbol The token's symbol.
 * @param options Intl.NumberFormatOptions for formatting.
 * @returns A formatted string like "1,234.56 SYMBOL".
 */
export function formatTokenAmount(
  amountStr: string,
  decimals: number,
  symbol: string,
  options?: Intl.NumberFormatOptions,
  allowCompact = true,
  locale = 'en-US'
): string {
  amountStr = amountStr ? amountStr.trim() : '';
  const isNFT = symbol.toUpperCase().includes('ERC1155') || symbol.toUpperCase().includes('ERC721');

  // For NFTs, the amount is not relevant, just display "NFT"
  if (isNFT) {
    return 'NFT';
  }

  if (!amountStr || !/^\d+$/.test(amountStr)) {
    const zero = (0).toLocaleString(locale, options || { minimumFractionDigits: 2 });
    return `${zero} ${symbol}`;
  }

  // Handle other tokens with 0 decimals
  if (decimals === 0) {
    const amount = BigInt(amountStr);
    return `${amount.toLocaleString(locale)} ${symbol}`;
  }

  try {
    const amount = BigInt(amountStr);
    const divisor = BigInt(10 ** decimals);
    const fullNumberStr = `${amount / divisor}.${(amount % divisor).toString().padStart(decimals, '0')}`;
    const numericValue = parseFloat(fullNumberStr);

    // 1. Compact notation for very large numbers (if allowed)
    if (allowCompact && numericValue >= 1_000) {
      return `${numericValue.toLocaleString(locale, {
        notation: 'compact',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })} ${symbol}`;
    }

    // 2. Dynamic precision for small numbers
    const formattingOptions = options || {};
    if (!options) {
      if (numericValue > 0 && numericValue < 1) {
        formattingOptions.maximumFractionDigits = 6;
      } else {
        formattingOptions.minimumFractionDigits = 2;
        formattingOptions.maximumFractionDigits = 2;
      }
    }

    return `${numericValue.toLocaleString(locale, formattingOptions)} ${symbol}`;
  } catch (error) {
    console.error('Error formatting token amount:', { amountStr, decimals, symbol, error });
    const zero = (0).toLocaleString(locale, { minimumFractionDigits: 2 });
    return `${zero} ${symbol}`;
  }
}

export function formatAmount(amount: string, decimals: number, symbol: string, locale = 'en-US'): string {
  // Pass `undefined` for options to trigger dynamic formatting logic
  return formatTokenAmount(amount, decimals, symbol, undefined, true, locale);
}

// Assuming REEF token decimals (18) for fees as it's the native token.
const REEF_DECIMALS = 18;

export function formatFee(feeAmount: string, feeTokenSymbol: string, locale = 'en-US'): string {
  // Pass explicit options to override dynamic logic and ensure high precision
  return formatTokenAmount(
    feeAmount,
    REEF_DECIMALS,
    feeTokenSymbol,
    {
      minimumFractionDigits: 2,
      maximumFractionDigits: 8, // Show more precision for fees
    },
    false, // Do not use compact notation for fees
    locale
  );
}
